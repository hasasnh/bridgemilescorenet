﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace CaptureScreenClient
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int port = 6363;
            string ipAddress = "127.0.0.1";

            TcpClient TcpClient = new TcpClient();
            TcpClient.Connect(ipAddress, port);


            BinaryFormatter f = new BinaryFormatter();
            var msg = f.Deserialize(TcpClient.GetStream());

            Bitmap bm = new Bitmap(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height);
            Graphics g = Graphics.FromImage(bm);
            g.CopyFromScreen(0, 0, 0, 0, bm.Size);
            MemoryStream memoryStream = new MemoryStream();
            bm.Save(memoryStream, System.Drawing.Imaging.ImageFormat.Jpeg);

            BinaryFormatter fs = new BinaryFormatter();
            fs.Serialize(TcpClient.GetStream(), memoryStream);

        }
    }
}
